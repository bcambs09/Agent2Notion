from langgraph.managed.context import Context as ContextManagedValue

Context = ContextManagedValue.of

__all__ = ["Context"]
