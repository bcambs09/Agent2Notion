# DOCKER-COMPOSE MOVED
All documentation for docker-compose has been moved to the helm repository.
You can find it [here](https://github.com/langchain-ai/helm/blob/main/charts/langsmith/docker-compose/docker-compose.yaml)
